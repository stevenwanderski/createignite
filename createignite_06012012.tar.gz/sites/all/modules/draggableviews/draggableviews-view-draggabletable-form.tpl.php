<?php
/**
 * @file
 * Template to merge the views output with some module-specific output.
 *
 * - $view: The view output.
 * - $form: All rendered form elements.
 */

print $view;
print $form_elements;