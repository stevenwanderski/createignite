// (function($){
  
	// $(function(){
	// 	var page_count = $('.pager-list li').length;
	// 	var pager_width = page_count * 17.4;
	// 	$('.pager').css('width', pager_width);
	// });

// }(jQuery));